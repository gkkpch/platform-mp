DIR=/usr/lib/u-boot
write_uboot_platform () 
{ 
    dd if="$1/u-boot.bin.sd.bin" of="$2" conv=fsync,notrunc bs=442 count=1 > /dev/null 2>&1;
    dd if="$1/u-boot.bin.sd.bin" of="$2" conv=fsync,notrunc bs=512 skip=1 seek=1 > /dev/null 2>&1
}
write_uboot_platform_ext () 
{ 
    dd if="$1/u-boot.bin" of=/dev/bootloader conv=fsync bs=1 seek=512 > /dev/null 2>&1;
    dd if="$1/u-boot.bin" of=/dev/mmcblk0boot0 conv=fsync bs=1 seek=512 > /dev/null 2>&1;
    dd if="$1/u-boot.bin" of=/dev/mmcblk0boot1 conv=fsync bs=1 seek=512 > /dev/null 2>&1
}
setup_write_uboot_platform () 
{ 
    if grep -q "ubootpart" /proc/cmdline; then
        local tmp=$(cat /proc/cmdline);
        local ubootpart="${tmp##*ubootpart=}";
        local imagetype="${tmp##*imagetype=}";
        ubootpart="${ubootpart%% *}";
        imagetype="${imagetype%% *}";
        if [ "$imagetype" == "SD-USB" ] || [ "$imagetype" == "EMMC_MBR" ]; then
            [[ -n $ubootpart && $ubootpart != NULL ]] && local part=$(findfs PARTUUID=$ubootpart 2>/dev/null);
            [[ -n $part ]] && local dev=$(lsblk -n -o PKNAME $part 2>/dev/null);
            [[ -n $dev ]] && DEVICE="/dev/$dev";
        else
            if [ "$imagetype" == "EMMC" ]; then
                DEVICE="VENDOR";
            fi;
        fi;
    fi
}
